#!/bin/bash

#!/bin/bash

./noncerpro --address='NQ65 LLKU JVH5 0DL7 0JBH GL6S UAPD 343L KFFB' --threads=4 --server=nimiq.icemining.ca --port=2053 -x='m=solo' 
